"""
Driver roster service.

Keeps a small pool of drivers persisted to data/drivers.json, each with an
availability status ("available" / "busy"). order_service.py pulls an
available driver when an order is confirmed, and frees them again once the
order is delivered or cancelled.
"""

import json
from pathlib import Path
from typing import Dict, List, Optional

from app.core.config import settings

DEFAULT_DRIVERS: List[Dict] = [
    {"driver_id": "DRV-001", "name": "Ali Raza", "phone": "+92-300-1111111", "vehicle_type": "Bike", "status": "available"},
    {"driver_id": "DRV-002", "name": "Usman Tariq", "phone": "+92-300-2222222", "vehicle_type": "Bike", "status": "available"},
    {"driver_id": "DRV-003", "name": "Bilal Ahmed", "phone": "+92-300-3333333", "vehicle_type": "Car", "status": "available"},
]


def _drivers_path() -> Path:
    return settings.DATA_DIR / "drivers.json"


def _load_drivers() -> List[Dict]:
    path = _drivers_path()
    if not path.exists():
        _save_drivers(DEFAULT_DRIVERS)
        return [d.copy() for d in DEFAULT_DRIVERS]
    with open(path, "r") as f:
        return json.load(f)


def _save_drivers(drivers: List[Dict]) -> None:
    path = _drivers_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(drivers, f, indent=2)


def list_drivers() -> List[Dict]:
    return _load_drivers()


def get_available_driver() -> Optional[Dict]:
    """Returns the first available driver, or None if the whole roster is busy."""
    for d in _load_drivers():
        if d["status"] == "available":
            return d
    return None


def set_driver_status(driver_id: str, status: str) -> Optional[Dict]:
    drivers = _load_drivers()
    updated = None
    for d in drivers:
        if d["driver_id"] == driver_id:
            d["status"] = status
            updated = d
            break
    if updated is not None:
        _save_drivers(drivers)
    return updated