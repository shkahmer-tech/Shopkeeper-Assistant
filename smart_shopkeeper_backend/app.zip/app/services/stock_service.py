"""
Current stock tracking service.

Keeps a single persisted "current stock" value under data/stock_state.json
so the shopkeeper only sets it once (or on restock) instead of retyping it
on every inventory check. Every recorded sale automatically decrements it.
"""

import json
from datetime import datetime
from pathlib import Path
from typing import Tuple

from app.core.config import settings


def _stock_path() -> Path:
    return settings.DATA_DIR / "stock_state.json"


def get_current_stock() -> float:
    """Returns the persisted current stock, or 0.0 if never set."""
    path = _stock_path()
    if not path.exists():
        return 0.0
    with open(path, "r") as f:
        data = json.load(f)
    return float(data.get("current_stock", 0.0))


def set_current_stock(value: float) -> float:
    """Overwrites the current stock — use this for the initial value or a restock."""
    path = _stock_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    data = {"current_stock": float(value), "updated_at": datetime.utcnow().isoformat()}
    with open(path, "w") as f:
        json.dump(data, f)
    return data["current_stock"]


def record_sale(units_sold: float) -> Tuple[float, float]:
    """
    Decrements current stock by units_sold (never below 0).
    Returns (previous_stock, updated_stock).
    """
    previous = get_current_stock()
    updated = max(0.0, previous - units_sold)
    set_current_stock(updated)
    return previous, updated