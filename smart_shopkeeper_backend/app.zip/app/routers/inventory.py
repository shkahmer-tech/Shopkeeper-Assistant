"""
Inventory management routes.

  POST /api/inventory/set-stock - set/reset the current stock value (initial setup or restock)
  POST /api/inventory/sell      - record a sale: auto-decrements stock, optionally trains the demand model
  POST /api/inventory/check     - get reorder status using the STORED stock + a live demand forecast
                                   (every check is also logged to data/inventory_log.csv)
"""

from datetime import date

from fastapi import APIRouter, HTTPException

from app.core.config import settings
from app.models.schemas import (
    InventoryCheckRequest,
    InventoryCheckResponse,
    SellUnitsRequest,
    SellUnitsResponse,
    SetStockRequest,
    SetStockResponse,
)
from app.services import demand_service, inventory_service, stock_service
from app.utils.data_loader import DataLoadError

router = APIRouter(prefix="/api/inventory", tags=["Inventory Management"])


@router.post("/set-stock", response_model=SetStockResponse)
def set_stock(payload: SetStockRequest):
    """Use this once initially, and again any time you physically restock."""
    updated = stock_service.set_current_stock(payload.current_stock)
    return SetStockResponse(
        current_stock=updated,
        message="Current stock updated.",
    )


@router.post("/sell", response_model=SellUnitsResponse)
def sell_units(payload: SellUnitsRequest):
    """
    Record a real sale. This does two things:
    1. Decrements the stored current stock by units_sold.
    2. (Optional, default on) Saves this as a real demand data point and
       retrains the demand model immediately, so future forecasts reflect it.
    """
    previous_stock, updated_stock = stock_service.record_sale(payload.units_sold)

    demand_record_added = False
    retrained = False
    if payload.add_to_training_data:
        try:
            sale_date = payload.date or str(date.today())
            record = {
                settings.DEMAND_DATE_COL: sale_date,
                settings.DEMAND_TARGET_COL: payload.units_sold,
            }
            if payload.extra_fields:
                record.update(payload.extra_fields)

            rows_in_master, trained = demand_service.add_single_demand_record(
                record, retrain=True
            )
            demand_record_added = True
            retrained = trained is not None
        except DataLoadError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

    return SellUnitsResponse(
        previous_stock=previous_stock,
        units_sold=payload.units_sold,
        updated_stock=updated_stock,
        demand_record_added=demand_record_added,
        retrained=retrained,
        message=f"Sale recorded. Stock updated from {previous_stock} to {updated_stock}.",
    )


@router.post("/check", response_model=InventoryCheckResponse)
def check_inventory(payload: InventoryCheckRequest):
    """
    Uses the STORED current stock (set via /set-stock, maintained by /sell)
    and a live demand forecast for the given date — no need to type stock
    or demand numbers manually anymore.
    """
    target_date = payload.target_date or str(date.today())

    try:
        _, _, weekly_demand, monthly_demand = demand_service.forecast_demand(target_date)
    except demand_service.ModelNotTrainedError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc

    current_stock = stock_service.get_current_stock()

    reorder, status, note = inventory_service.check_inventory(
        current_stock, weekly_demand, monthly_demand
    )

    inventory_service.log_inventory_check(
        current_stock, weekly_demand, monthly_demand, status, reorder
    )

    return InventoryCheckResponse(
        current_stock=current_stock,
        weekly_demand=weekly_demand,
        monthly_demand=monthly_demand,
        status=status,
        reorder_units=reorder,
        action_note=note,
        logged=True,
    )